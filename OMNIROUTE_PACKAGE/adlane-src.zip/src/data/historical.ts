// Données historiques migrées depuis l'artéfact initial
// Conforme à HANDOFF-PARIS-FOOT.md §3 et §4

import { Bet, Lesson, MarketCalibration } from '../types';

export const HISTORICAL_BETS: Bet[] = [
  {
    id: 'j4-c01',
    version: 1,
    date: '2026-09-12',
    creneau_utc: '2026-09-12T14:00:00Z',
    creneau_display: '12/09 15:00',
    league: 'Premier League',
    legs: [
      {
        id: 'j4-c01-l1',
        match: 'Bournemouth - Brentford',
        kickoff_utc: '2026-09-12T14:00:00Z',
        league: 'Premier League',
        market: 'BTTS',
        selection: 'Les deux équipes marquent (Oui)',
        odds: 1.55,
        estimated_prob: 0.65,
        is_void: false,
        result: 'won',
        stat_observed: 'Score 1-2'
      },
      {
        id: 'j4-c01-l2',
        match: 'Aston Villa - Nottingham Forest',
        kickoff_utc: '2026-09-12T14:00:00Z',
        league: 'Premier League',
        market: 'BTTS',
        selection: 'Les deux équipes marquent (Oui)',
        odds: 1.52,
        estimated_prob: 0.62,
        is_void: false,
        result: 'won',
        stat_observed: 'Score 1-1'
      },
      {
        id: 'j4-c01-l3',
        match: 'Chelsea - Hull City',
        kickoff_utc: '2026-09-12T14:00:00Z',
        league: 'Championship / FA Cup',
        market: 'OU_2_5',
        selection: 'Plus de 2,5 buts',
        odds: 1.21,
        estimated_prob: 0.78,
        is_void: false,
        result: 'won',
        stat_observed: 'Score 3-1'
      }
    ],
    odds: 2.852,
    stake: 5,
    payout: 14.26,
    net_pnl: 9.26,
    excluded_from_pnl: false,
    status: 'won',
    played: true,
    confiance: 75,
    confidence_level: 'Élevé',
    analysis: 'Combiné 3 jambes de volume validé.',
    validation_flags: [],
    createdAt: '2026-09-12T12:00:00Z',
    updatedAt: '2026-09-12T18:00:00Z'
  },
  {
    id: 'j4-c02',
    version: 1,
    date: '2026-09-12',
    creneau_utc: '2026-09-12T14:00:00Z',
    creneau_display: '12/09 15:00',
    league: 'Premier League',
    legs: [
      {
        id: 'j4-c02-l1',
        match: 'Crystal Palace - Wolves',
        kickoff_utc: '2026-09-12T14:00:00Z',
        league: 'Premier League',
        market: '1X2',
        selection: 'Victoire Crystal Palace',
        odds: 2.06,
        estimated_prob: 0.485, // 48.5% -> Point de rupture §4.2
        is_void: false,
        result: 'lost',
        stat_observed: 'Rouge Disasi 34e, défaite 2-3'
      },
      {
        id: 'j4-c02-l2',
        match: 'Bournemouth - Brentford',
        kickoff_utc: '2026-09-12T14:00:00Z',
        league: 'Premier League',
        market: 'BTTS',
        selection: 'Les deux équipes marquent (Oui)',
        odds: 1.55,
        estimated_prob: 0.656,
        is_void: false,
        result: 'won',
        stat_observed: 'Score 1-2'
      },
      {
        id: 'j4-c02-l3',
        match: 'Aston Villa - Nottingham Forest',
        kickoff_utc: '2026-09-12T14:00:00Z',
        league: 'Premier League',
        market: 'BTTS',
        selection: 'Les deux équipes marquent (Oui)',
        odds: 1.52,
        estimated_prob: 0.622,
        is_void: false,
        result: 'won',
        stat_observed: 'Score 1-1'
      }
    ],
    odds: 4.67,
    stake: 5,
    payout: 0,
    net_pnl: -5.0,
    excluded_from_pnl: false,
    status: 'lost',
    played: true,
    confiance: 55,
    confidence_level: 'Moyen',
    analysis: 'Perdu : Jambe 1X2 minoritaire à 48,5% sur Palace (rouge Disasi 34e, 2-3).',
    validation_flags: ['BLOCK_1X2_SOUS_50'],
    createdAt: '2026-09-12T12:00:00Z',
    updatedAt: '2026-09-12T18:00:00Z'
  },
  {
    id: 'j4-solo-sun-ars',
    version: 1,
    date: '2026-09-12',
    creneau_utc: '2026-09-12T16:30:00Z',
    creneau_display: '12/09 17:30',
    league: 'Premier League',
    legs: [
      {
        id: 'j4-solo-sun-ars-l1',
        match: 'Sunderland - Arsenal',
        kickoff_utc: '2026-09-12T16:30:00Z',
        league: 'Premier League',
        market: '1X2',
        selection: 'Victoire Arsenal',
        odds: 1.666,
        estimated_prob: 0.65,
        is_void: false,
        result: 'won',
        stat_observed: 'Victoire nette Arsenal'
      }
    ],
    odds: 1.666,
    stake: 10,
    payout: 16.66,
    net_pnl: 6.66,
    excluded_from_pnl: false,
    status: 'won',
    played: true,
    confiance: 80,
    confidence_level: 'Élevé',
    analysis: 'Victoire Arsenal confirmée.',
    validation_flags: [],
    createdAt: '2026-09-12T15:00:00Z',
    updatedAt: '2026-09-12T19:00:00Z'
  },
  {
    id: 'j4-solo-tot-eve',
    version: 1,
    date: '2026-09-12',
    creneau_utc: '2026-09-12T19:00:00Z',
    creneau_display: '12/09 20:00',
    league: 'Premier League',
    legs: [
      {
        id: 'j4-solo-tot-eve-l1',
        match: 'Tottenham - Everton',
        kickoff_utc: '2026-09-12T19:00:00Z',
        league: 'Premier League',
        market: 'BTTS',
        selection: 'Les deux équipes marquent (Oui)',
        odds: 1.60,
        estimated_prob: 0.574,
        is_void: false,
        result: 'lost',
        stat_observed: 'Score 0-0. Spurs 407 min sans marquer, Pickford 100e clean sheet.'
      }
    ],
    odds: 1.60,
    stake: 5,
    payout: 0,
    net_pnl: -5.0,
    excluded_from_pnl: false,
    status: 'lost',
    played: true,
    confiance: 60,
    confidence_level: 'Moyen',
    analysis: 'Perdu : Tottenham muet à domicile (407 min sans but, xG 0.64). BTTS biaisé à la hausse.',
    validation_flags: ['WARN_BTTS_NON_CALIBRE'],
    createdAt: '2026-09-12T18:00:00Z',
    updatedAt: '2026-09-12T22:00:00Z'
  },
  {
    id: 'slot1530z-solo-manutd-mancity',
    version: 1,
    date: '2026-09-13',
    creneau_utc: '2026-09-13T15:30:00Z',
    creneau_display: '13/09 16:30',
    league: 'Premier League',
    legs: [
      {
        id: 'slot1530z-l1',
        match: 'Manchester United - Manchester City',
        kickoff_utc: '2026-09-13T15:30:00Z',
        league: 'Premier League',
        market: '1X2',
        selection: 'Victoire Manchester City',
        odds: 2.225,
        estimated_prob: 0.52,
        is_void: false,
        result: 'won',
        stat_observed: 'Score 0-1 (City à 10 dès la 23e, but Haaland 60e)'
      }
    ],
    odds: 2.225,
    stake: 9.4,
    payout: 20.915,
    net_pnl: 11.515,
    excluded_from_pnl: false,
    status: 'won',
    played: true,
    confiance: 70,
    confidence_level: 'Élevé',
    analysis: 'Victoire Man City validée 0-1.',
    validation_flags: [],
    createdAt: '2026-09-13T14:00:00Z',
    updatedAt: '2026-09-13T18:00:00Z'
  },
  {
    id: 'j4-solo-mun-mci',
    version: 1,
    date: '2026-09-13',
    creneau_utc: '2026-09-13T15:30:00Z',
    creneau_display: '13/09 16:30',
    league: 'Premier League',
    legs: [
      {
        id: 'j4-solo-mun-mci-l1',
        match: 'Manchester United - Manchester City',
        kickoff_utc: '2026-09-13T15:30:00Z',
        league: 'Premier League',
        market: 'BTTS',
        selection: 'Les deux équipes marquent (Oui)',
        odds: 1.44,
        estimated_prob: 0.674,
        is_void: false,
        result: 'lost',
        stat_observed: 'Score 0-1. United muet à 11 contre 10.'
      }
    ],
    odds: 1.44,
    stake: 5,
    payout: 0,
    net_pnl: -5.0,
    excluded_from_pnl: false,
    status: 'lost',
    played: true,
    confiance: 75,
    confidence_level: 'Élevé',
    analysis: 'Perdu : Man United incapable de marquer face à une City en infériorité numérique.',
    validation_flags: ['WARN_BTTS_NON_CALIBRE'],
    createdAt: '2026-09-13T14:00:00Z',
    updatedAt: '2026-09-13T18:00:00Z'
  },
  {
    id: 'combo-override-13-09-div-1',
    version: 1,
    date: '2026-09-13',
    creneau_utc: '2026-09-13T18:00:00Z',
    creneau_display: '13/09 19:00',
    league: 'Multi-championnats',
    legs: [
      {
        id: 'div-1-l1',
        match: 'Sassuolo - Juventus',
        kickoff_utc: '2026-09-13T19:45:00Z',
        league: 'Serie A',
        market: 'shots_on_target',
        selection: 'Berardi au moins 1 tir cadré',
        odds: 1.46,
        estimated_prob: 0.70,
        is_void: false,
        result: 'won',
        stat_observed: '1 tir cadré'
      },
      {
        id: 'div-1-l2',
        match: 'Real Sociedad - Atlético Madrid',
        kickoff_utc: '2026-09-13T20:00:00Z',
        league: 'La Liga',
        market: 'OU_2_5',
        selection: 'Plus de 2,5 buts',
        odds: 1.99,
        estimated_prob: 0.58,
        is_void: false,
        result: 'won',
        stat_observed: 'Score 0-3 (3 buts)'
      },
      {
        id: 'div-1-l3',
        match: 'Brest - PSG',
        kickoff_utc: '2026-09-13T20:00:00Z',
        league: 'Ligue 1',
        market: 'shots_on_target',
        selection: 'Doué au moins 1 tir cadré',
        odds: 1.50,
        estimated_prob: 0.65,
        is_void: true, // Jambe voidée -> cote recalculée 1.46 * 1.99 = 2.906
        result: 'void',
        stat_observed: 'Non titulaire / non entré'
      }
    ],
    odds: 2.906, // 1.46 * 1.99 après void Doué (§2.1 / §7.3)
    stake: 5,
    payout: 14.53,
    net_pnl: 9.53,
    excluded_from_pnl: false,
    status: 'won',
    played: true,
    confiance: 70,
    confidence_level: 'Moyen',
    analysis: 'Gagné après recalcul de cote suite à jambe Doué void.',
    validation_flags: [],
    createdAt: '2026-09-13T17:00:00Z',
    updatedAt: '2026-09-13T23:00:00Z'
  },
  {
    id: 'combo-override-13-09-div-2',
    version: 1,
    date: '2026-09-13',
    creneau_utc: '2026-09-13T18:00:00Z',
    creneau_display: '13/09 19:00',
    league: 'Multi-championnats',
    legs: [
      {
        id: 'div-2-l1',
        match: 'Sassuolo - Juventus',
        kickoff_utc: '2026-09-13T19:45:00Z',
        league: 'Serie A',
        market: 'corners',
        selection: 'Plus de 8,5 corners',
        odds: null, // Cote non publiée -> BLOCK_COTE_MANQUANTE
        estimated_prob: 0.60,
        is_void: false,
        result: 'pending'
      }
    ],
    odds: null,
    stake: null,
    payout: 0,
    net_pnl: 0,
    excluded_from_pnl: true,
    status: 'proposed',
    played: false,
    confiance: null,
    confidence_level: 'Faible',
    analysis: 'Non joué : cote corners manquante chez le bookmaker.',
    validation_flags: ['BLOCK_COTE_MANQUANTE'],
    createdAt: '2026-09-13T17:00:00Z',
    updatedAt: '2026-09-13T17:00:00Z'
  },
  {
    id: 'combo-override-13-09-div-3',
    version: 1,
    date: '2026-09-13',
    creneau_utc: '2026-09-13T18:00:00Z',
    creneau_display: '13/09 19:00',
    league: 'Multi-championnats',
    legs: [
      {
        id: 'div-3-l1',
        match: 'Sassuolo - Juventus',
        kickoff_utc: '2026-09-13T19:45:00Z',
        league: 'Serie A',
        market: '1X2',
        selection: 'Match nul',
        odds: 3.75,
        estimated_prob: 0.27, // ~27% -> Rejeté par validateur §4.2
        is_void: false,
        result: 'lost',
        stat_observed: 'Score 3-2 (Sassuolo gagne avec 3 buts après 89e)'
      },
      {
        id: 'div-3-l2',
        match: 'Brest - PSG',
        kickoff_utc: '2026-09-13T20:00:00Z',
        league: 'Ligue 1',
        market: '1X2',
        selection: 'Victoire PSG',
        odds: 1.45,
        estimated_prob: 0.68,
        is_void: false,
        result: 'won',
        stat_observed: 'Victoire PSG 0-1'
      }
    ],
    odds: 11.342,
    stake: 2.5,
    payout: 0,
    net_pnl: -2.5,
    excluded_from_pnl: false,
    status: 'lost',
    played: true,
    confiance: 40,
    confidence_level: 'Faible',
    analysis: 'Perdu : Nul Sassuolo-Juve brisé par 3 buts tardifs (3-2). Leçon 1X2 < 50%.',
    validation_flags: ['BLOCK_1X2_SOUS_50'],
    createdAt: '2026-09-13T17:00:00Z',
    updatedAt: '2026-09-13T23:00:00Z'
  },
  {
    id: 'combo-override-13-09-div-4',
    version: 1,
    date: '2026-09-13',
    creneau_utc: '2026-09-13T18:00:00Z',
    creneau_display: '13/09 19:00',
    league: 'Multi-championnats',
    legs: [
      {
        id: 'div-4-l1',
        match: 'Real Sociedad - Atlético Madrid',
        kickoff_utc: '2026-09-13T20:00:00Z',
        league: 'La Liga',
        market: 'BTTS',
        selection: 'Les deux équipes marquent (Oui)',
        odds: 1.85,
        estimated_prob: 0.58,
        is_void: false,
        result: 'lost',
        stat_observed: 'Score 0-3 (Real blanchie)'
      },
      {
        id: 'div-4-l2',
        match: 'Brest - PSG',
        kickoff_utc: '2026-09-13T20:00:00Z',
        league: 'Ligue 1',
        market: '1X2',
        selection: 'Victoire PSG',
        odds: 1.45,
        estimated_prob: 0.68,
        is_void: false,
        result: 'won',
        stat_observed: 'Score 0-1'
      }
    ],
    odds: 5.156,
    stake: 5,
    payout: 0,
    net_pnl: -5.0,
    excluded_from_pnl: false,
    status: 'lost',
    played: true,
    confiance: 55,
    confidence_level: 'Moyen',
    analysis: 'Perdu : Real Sociedad blanchie à domicile (0-3).',
    validation_flags: ['WARN_BTTS_NON_CALIBRE'],
    createdAt: '2026-09-13T17:00:00Z',
    updatedAt: '2026-09-13T23:00:00Z'
  },
  {
    id: 'combo-override-13-09-div-5',
    version: 1,
    date: '2026-09-13',
    creneau_utc: '2026-09-13T18:00:00Z',
    creneau_display: '13/09 19:00',
    league: 'Multi-championnats',
    legs: [
      {
        id: 'div-5-l1',
        match: 'Sassuolo - Juventus',
        kickoff_utc: '2026-09-13T19:45:00Z',
        league: 'Serie A',
        market: 'OU_2_5',
        selection: 'Moins de 2,5 buts',
        odds: 1.80,
        estimated_prob: 0.55,
        is_void: false,
        result: 'lost',
        stat_observed: 'Score 3-2 (5 buts au total)'
      },
      {
        id: 'div-5-l2',
        match: 'Brest - PSG',
        kickoff_utc: '2026-09-13T20:00:00Z',
        league: 'Ligue 1',
        market: '1X2',
        selection: 'Victoire PSG',
        odds: 1.45,
        estimated_prob: 0.68,
        is_void: false,
        result: 'won',
        stat_observed: 'Score 0-1'
      }
    ],
    odds: 12.987,
    stake: 2.5,
    payout: 0,
    net_pnl: -2.5,
    excluded_from_pnl: false,
    status: 'lost',
    played: true,
    confiance: 45,
    confidence_level: 'Faible',
    analysis: 'Perdu : 5 buts inscrits dans Sassuolo-Juventus (3-2). Auto-annulation avec div-1.',
    validation_flags: ['ERROR_AUTO_ANNULATION'],
    createdAt: '2026-09-13T17:00:00Z',
    updatedAt: '2026-09-13T23:00:00Z'
  },
  {
    id: 'j4-solo-lee-new',
    version: 1,
    date: '2026-09-14',
    creneau_utc: '2026-09-14T19:00:00Z',
    creneau_display: '14/09 20:00',
    league: 'Premier League',
    legs: [
      {
        id: 'j4-lee-new-l1',
        match: 'Leeds - Newcastle',
        kickoff_utc: '2026-09-14T19:00:00Z',
        league: 'Premier League',
        market: '1X2',
        selection: 'Victoire Newcastle',
        odds: null,
        estimated_prob: 0.55,
        is_void: false,
        result: 'pending'
      }
    ],
    odds: null,
    stake: null,
    payout: 0,
    net_pnl: 0,
    excluded_from_pnl: true,
    status: 'proposed',
    played: false,
    confiance: 65,
    confidence_level: 'Moyen',
    analysis: 'Pari proposé pour le lundi 14/09 19h.',
    validation_flags: [],
    createdAt: '2026-09-14T10:00:00Z',
    updatedAt: '2026-09-14T10:00:00Z'
  }
];

export const HISTORICAL_LESSONS: Lesson[] = [
  {
    doc_id: 'btts-equipe-en-disette',
    motif: 'BTTS Oui surestimé sur équipes en disette ou face à de grands gardiens',
    occurrences: 3,
    regle_validation: 'WARN_BTTS_NON_CALIBRE',
    detail: 'Sur 5 sélections BTTS récentes, 3 ont échoué (Tottenham-Everton 0-0, Man Utd-Man City 0-1, Real Sociedad-Atlético 0-3). Malus automatique si >=3 matchs sans but ou gardien à 2+ clean sheets. Une expulsion adverse n\'est pas haussière.',
    derniere_maj: '2026-09-14'
  },
  {
    doc_id: 'leg-1x2-sous-50-pourcent',
    motif: 'Jambe 1X2 sous 50% dans un combiné est le point de rupture systématique',
    occurrences: 2,
    regle_validation: 'BLOCK_1X2_SOUS_50',
    detail: 'Cas Crystal Palace 48.5% (rouge 34e, 2-3) et Nul Sassuolo-Juve 27% (3 buts après 89e). Un 1X2 < 50% ou un nul sec est interdit dans tout combiné car trop exposé aux faits de jeu (VAR, rouge, penalty).',
    derniere_maj: '2026-09-14'
  },
  {
    doc_id: 'faux-combines-memes-matchs',
    motif: 'Diversification illusoire : plusieurs combinés sur le même groupe de matchs',
    occurrences: 1,
    regle_validation: 'WARN_EXPOSITION_MATCH',
    detail: '5 combinés bâtis sur les 3 mêmes rencontres le 13/09. Deux issues mal anticipées ont détruit 3 slips simultanément. Alerte dès qu\'un match dépasse 2 slips et blocage si auto-annulation.',
    derniere_maj: '2026-09-14'
  },
  {
    doc_id: 'j4-echec-taches-planifiees-14h',
    motif: 'Pronostic émis après coup d\'envoi suite à échec de tâche planifiée',
    occurrences: 3,
    regle_validation: 'BLOCK_KICKOFF_DEPASSE',
    detail: 'Garde-fou dur : avant publication, now_utc >= kickoff_utc entraîne un refus strict. Tout état de tâche doit être observable (SUCCEEDED/FAILED/TIMEOUT).',
    derniere_maj: '2026-09-14'
  }
];

export const INITIAL_CALIBRATIONS: MarketCalibration[] = [
  {
    market: '1X2',
    total_predictions: 9,
    predictions_won: 4,
    actual_success_rate: 0.444,
    avg_predicted_prob: 0.58,
    calibration_status: 'calibre',
    last_updated: '2026-09-14T00:00:00Z'
  },
  {
    market: 'BTTS',
    total_predictions: 9,
    predictions_won: 5,
    actual_success_rate: 0.556,
    avg_predicted_prob: 0.65,
    calibration_status: 'suspect', // Biais haussier avéré (§4.1)
    last_updated: '2026-09-14T00:00:00Z'
  },
  {
    market: 'OU_2_5',
    total_predictions: 9,
    predictions_won: 5,
    actual_success_rate: 0.556,
    avg_predicted_prob: 0.62,
    calibration_status: 'calibre',
    last_updated: '2026-09-14T00:00:00Z'
  },
  {
    market: 'corners',
    total_predictions: 0,
    predictions_won: 0,
    actual_success_rate: 0,
    avg_predicted_prob: 0,
    calibration_status: 'non_calibre', // Zéro historique (§4.5)
    last_updated: '2026-09-14T00:00:00Z'
  },
  {
    market: 'shots_on_target',
    total_predictions: 1,
    predictions_won: 1,
    actual_success_rate: 1.0,
    avg_predicted_prob: 0.70,
    calibration_status: 'non_calibre',
    last_updated: '2026-09-14T00:00:00Z'
  }
];
